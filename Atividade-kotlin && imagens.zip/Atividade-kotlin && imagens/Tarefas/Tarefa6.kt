println("Last event of the day: ${events.last().title}")
